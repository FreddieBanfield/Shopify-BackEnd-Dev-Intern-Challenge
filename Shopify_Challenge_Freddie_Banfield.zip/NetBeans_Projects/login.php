<?php
session_start();
require 'connectToDatabase.php';

$name = filter_input(INPUT_POST, 'username');
$pass = filter_input(INPUT_POST, 'password');

$query = "SELECT * FROM Users WHERE username = '" . $name . "' AND password = '" . $pass . "';";

$result = mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);

$mysqli->close();

if (mysqli_num_rows($result) >= 1){
    $_SESSION['username'] = $name;
    $_SESSION['password'] = $pass;
    header("location: createItem.php");
}else{
    header("location: login.html");
}

?>