<?php

//Loads in html for creating an account
$createAccount = file_get_contents('createAccount.html');

//print html code
echo $createAccount;
?>
