<?php

require 'header.php';
require 'createItem.html';
require 'connectToDatabase.php';

if (filter_input(INPUT_POST, 'vin')){
    
    //Notifies user bike has been added
    $brand = filter_input(INPUT_POST, 'brand');
    $model = filter_input(INPUT_POST, 'model');
    $year = filter_input(INPUT_POST, 'year');
    $type = filter_input(INPUT_POST, 'type');
    $vin = filter_input(INPUT_POST, 'vin');
    
    $username = $_SESSION['username'];

    //Adds motorcycle to database in the motorcycle table
    $query = "INSERT INTO Motorcycle (brand, model, year, type, vin) VALUES('" .$brand . "', '" . $model . "', '" . $year ."', '" . $type ."', '" . $vin ."');";
    mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);

    //Connects motorcycle to user in inventory table
    $query = "INSERT INTO Inventory (username, vin) VALUES('" .$username . "', '" . $vin . "');";
    mysqli_query($mysqli, $query) or $error = $error . " and " . mysqli_error($mysqli);
    
    $mysqli->close();
    
    if ($error != "") {
        // Display the alert box for a fail
        echo '<script>alert("Bike was unable to be added \nError: ' . $error . '")</script>';
    } else {
        // Display the alert box for a success
        echo '<script>alert("Bike Added")</script>';
    }
    
}else{
    
}

?>
