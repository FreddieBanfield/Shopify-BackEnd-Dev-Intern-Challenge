<?php
//this code is used when a user submits a create account form form createAccount.html
//It will either display success and user is created or fail and the error to why
require 'connectToDatabase.php';

$name = filter_input(INPUT_POST, 'username');
$pass = filter_input(INPUT_POST, 'password');

$query = "INSERT INTO Users (username, password) VALUES('" .$name . "', '" . $pass ."');";

$result = mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);

$mysqli->close();

if ($error != "") {
    $heading = "Error - " . $error;
} else {
    $heading = 'Success - User "' . $name . '" has been created!';
}
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Inventory System</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="resources/css/styles.css"> 
    </head>
    <body class="center_content">
        <h1><?php echo $heading ?></h1>
        <a href="index.php">back to create page</a>
    </body>
</html>