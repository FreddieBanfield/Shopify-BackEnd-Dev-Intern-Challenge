<?php

require 'header.php';
require 'connectToDatabase.php';

$name = $_SESSION['username'];

//Checks if user has requested to edit a item
if(filter_input(INPUT_POST, "vin")){
    
    $vin = filter_input(INPUT_POST, "vin");
    
    //Get information on selected motorcycle
    $query = 'SELECT * FROM Motorcycle WHERE vin = "' . $vin . '";';
    $result = mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);
    
    
    if ($error != "") {
        echo '<script>alert("Unable to edit Motorcycle\nError: ' . $error . '")</script>';
    }
    
    if (mysqli_num_rows($result) > 0){
        while($info = mysqli_fetch_array($result)){
            $brand = stripslashes($info["brand"]);
            $model = stripslashes($info["model"]);
            $year = stripslashes($info["year"]);
            $type = stripslashes($info["type"]);
            $vin = stripslashes($info["vin"]);
        }
    }
    //send over old vin, so that commitEdit.php can do its deletion querries
    $old_vin = $vin;
    
    //This gets the index this year is in the html code, I use javascript to then set the value to that index to get the year to display
    $year = $year - 1900;
    
    //Similar concept to that above, but with the motorcycle types. Not the most scalable, so I would definitly revisit in future.
    switch ($type){
        case "sport":
            $type = 0;
            break;
        case "tourer":
            $type = 1;
            break;
        case "standard":
            $type = 2;
            break;
        case "cruiser":
            $type = 3;
            break;
        case "dual-sport":
            $type = 4;
            break;
        case "dirt-bike":
            $type = 5;
            break;
        case "scooter":
            $type = 6;
            break;
        case "other":
            $type = 7;
            break;
        
    }
    
    //Output form to edit motorcycle that is selected
    $htmlLayout = '<!DOCTYPE html>

<html>
    <head>
        <title>Inventory System</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="resources/css/styles.css"> 
    </head>
    <body>
        <div>
            <div class="center_content center_text">
                <h2>Edit Motorcycle for Inventory</h2>
                <br>
                <form id="account_form" action="commitEdit.php" method="POST" name="loginForm">
                    <label for="brand">Brand:</label><br>
                    <input type="text" id="brand" name="brand" value="' . $brand . '" required><br>
                    <label for="model">Model:</label><br>
                    <input type="text" id="model" name="model" value="' . $model . '" required><br>
                    <label for="year">Year:</label><br>
                    <select id="year" name="year">
                        <option value="1900">1900</option>
                        <option value="1901">1901</option>
                        <option value="1902">1902</option>
                        <option value="1903">1903</option>
                        <option value="1904">1904</option>
                        <option value="1905">1905</option>
                        <option value="1906">1906</option>
                        <option value="1907">1907</option>
                        <option value="1908">1908</option>
                        <option value="1909">1909</option>
                        <option value="1910">1910</option>
                        <option value="1911">1911</option>
                        <option value="1912">1912</option>
                        <option value="1913">1913</option>
                        <option value="1914">1914</option>
                        <option value="1915">1915</option>
                        <option value="1916">1916</option>
                        <option value="1917">1917</option>
                        <option value="1918">1918</option>
                        <option value="1919">1919</option>
                        <option value="1920">1920</option>
                        <option value="1921">1921</option>
                        <option value="1922">1922</option>
                        <option value="1923">1923</option>
                        <option value="1924">1924</option>
                        <option value="1925">1925</option>
                        <option value="1926">1926</option>
                        <option value="1927">1927</option>
                        <option value="1928">1928</option>
                        <option value="1929">1929</option>
                        <option value="1930">1930</option>
                        <option value="1931">1931</option>
                        <option value="1932">1932</option>
                        <option value="1933">1933</option>
                        <option value="1934">1934</option>
                        <option value="1935">1935</option>
                        <option value="1936">1936</option>
                        <option value="1937">1937</option>
                        <option value="1938">1938</option>
                        <option value="1939">1939</option>
                        <option value="1940">1940</option>
                        <option value="1941">1941</option>
                        <option value="1942">1942</option>
                        <option value="1943">1943</option>
                        <option value="1944">1944</option>
                        <option value="1945">1945</option>
                        <option value="1946">1946</option>
                        <option value="1947">1947</option>
                        <option value="1948">1948</option>
                        <option value="1949">1949</option>
                        <option value="1950">1950</option>
                        <option value="1951">1951</option>
                        <option value="1952">1952</option>
                        <option value="1953">1953</option>
                        <option value="1954">1954</option>
                        <option value="1955">1955</option>
                        <option value="1956">1956</option>
                        <option value="1957">1957</option>
                        <option value="1958">1958</option>
                        <option value="1959">1959</option>
                        <option value="1960">1960</option>
                        <option value="1961">1961</option>
                        <option value="1962">1962</option>
                        <option value="1963">1963</option>
                        <option value="1964">1964</option>
                        <option value="1965">1965</option>
                        <option value="1966">1966</option>
                        <option value="1967">1967</option>
                        <option value="1968">1968</option>
                        <option value="1969">1969</option>
                        <option value="1970">1970</option>
                        <option value="1971">1971</option>
                        <option value="1972">1972</option>
                        <option value="1973">1973</option>
                        <option value="1974">1974</option>
                        <option value="1975">1975</option>
                        <option value="1976">1976</option>
                        <option value="1977">1977</option>
                        <option value="1978">1978</option>
                        <option value="1979">1979</option>
                        <option value="1980">1980</option>
                        <option value="1981">1981</option>
                        <option value="1982">1982</option>
                        <option value="1983">1983</option>
                        <option value="1984">1984</option>
                        <option value="1985">1985</option>
                        <option value="1986">1986</option>
                        <option value="1987">1987</option>
                        <option value="1988">1988</option>
                        <option value="1989">1989</option>
                        <option value="1990">1990</option>
                        <option value="1991">1991</option>
                        <option value="1992">1992</option>
                        <option value="1993">1993</option>
                        <option value="1994">1994</option>
                        <option value="1995">1995</option>
                        <option value="1996">1996</option>
                        <option value="1997">1997</option>
                        <option value="1998">1998</option>
                        <option value="1999">1999</option>
                        <option value="2000">2000</option>
                        <option value="2001">2001</option>
                        <option value="2002">2002</option>
                        <option value="2003">2003</option>
                        <option value="2004">2004</option>
                        <option value="2005">2005</option>
                        <option value="2006">2006</option>
                        <option value="2007">2007</option>
                        <option value="2008">2008</option>
                        <option value="2009">2009</option>
                        <option value="2010">2010</option>
                        <option value="2011">2011</option>
                        <option value="2012">2012</option>
                        <option value="2013">2013</option>
                        <option value="2014">2014</option>
                        <option value="2015">2015</option>
                        <option value="2016">2016</option>
                        <option value="2017">2017</option>
                        <option value="2018">2018</option>
                        <option value="2019">2019</option>
                        <option value="2020">2020</option>
                        <option value="2021">2021</option>
                        <option value="2022" selected="selected">2022</option>
                        <option value="2023">2023</option>
                        <option value="2024">2024</option>
                    </select>
                    <br>
                    <label for="type">Type:</label><br>
                    <select id="type" name="type">
                      <option value="sport">Sport</option>
                      <option value="tourer">Tourer</option>
                      <option value="standard">Standard</option>
                      <option value="cruiser">Cruiser</option>
                      <option value="dual-sport">Dual-Sport</option>
                      <option value="dirt-bike">Dirt-Bike</option>
                      <option value="scooter">Scooter</option>
                      <option value="other">Other</option>
                    </select>
                    <br>
                    <label for="vin">VIN(4 digits):</label><br>
                    <input type="text" id="vin" name="vin" value="' . $vin . '" required><br>
                    <input type="hidden" id="oldvin" name="oldvin" value="' . $old_vin . '">
                    <input type="submit" value="Edit Motorcycle">
                </form>
            </div>
        </div>
        <script>
            document.getElementById("year").selectedIndex = ' . $year .';
            document.getElementById("type").selectedIndex = ' . $type .';
        </script>
    </body>
</html>
';
    
}

$query = "SELECT m.brand, m.model, m.year, m.type, m.vin FROM Inventory i, Motorcycle m WHERE username = '" . $name . "' AND i.vin = m.vin;";

$result = mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);

$mysqli->close();

if ($error != "") {
    echo '<script>alert("Inventory list was unable to load\nError: ' . $error . '")</script>';
} else {
    //Check if html code is already set
    if($htmlLayout == ""){
        //Set html code
        $htmlLayout = '<!DOCTYPE HTML>
        <html>
            <head>
                <title>Inventory System</title>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="resources/css/styles.css"> 
            </head>
            <body>
                <script>
                    function myFunction() {
                       document.getElementById("demo").style.color = "red";
                    }
                </script>
                <br>
                <h2 class="center_text">Edit Motorcycle for Inventory</h2>
                <br>
                <div>
                    <table class="inventory_table center_content center_text">
                        <thead>
                            <tr>
                                <th>Brand</th>
                                <th>Model</th>
                                <th>year</th>
                                <th>type</th>
                                <th>VIN</th>
                            </tr>
                        </thead>
                        <tbody>';
                            if (mysqli_num_rows($result) > 0){
                                while($info = mysqli_fetch_array($result)){
                                    $brand = stripslashes($info["brand"]);
                                    $model = stripslashes($info["model"]);
                                    $year = stripslashes($info["year"]);
                                    $type = stripslashes($info["type"]);
                                    $vin = stripslashes($info["vin"]);

                                    $htmlLayout .= "<tr>
                                            <td>$brand</td>
                                            <td>$model</td>
                                            <td>$year</td>
                                            <td>$type</td>
                                            <td>$vin</td>
                                            <td>" . '
                                                <form action="editItem.php" method="POST" name="editItem">
                                                    <input type="hidden" value="' . $vin . '" name="vin"/>
                                                    <input type="submit" value="Select" name="select"/>
                                                </form>
                                            </td>
                                        </tr>';
                                }
                            }
                        $htmlLayout .=  '
                        </tbody>
                    </table>
                </div>
            </body>
        </html>';
    }
    //Output html code
    echo $htmlLayout;
}
?>