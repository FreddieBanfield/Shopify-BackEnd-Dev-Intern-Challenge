<?php

require 'header.php';
require 'connectToDatabase.php';

$name = $_SESSION['username'];

//Checks if user has requested to delete a item
if(filter_input(INPUT_POST, "vin")){
    
    $vin = filter_input(INPUT_POST, "vin");
    
    //Delete from table inventory first, due to constraints
    $query = 'DELETE FROM Inventory WHERE vin = "' . $vin . '";';
    $result = mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);
    
    //Delete from motorcycles second
    $query = 'DELETE FROM Motorcycle WHERE vin = "' . $vin . '";';
    $result = mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);
    
    if ($error != "") {
        echo '<script>alert("Unable to Delete Motorcycle\nError: ' . $error . '")</script>';
    }

}

$query = "SELECT m.brand, m.model, m.year, m.type, m.vin FROM Inventory i, Motorcycle m WHERE username = '" . $name . "' AND i.vin = m.vin;";

$result = mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);

$mysqli->close();

if ($error != "") {
    echo '<script>alert("Inventory list was unable to load\nError: ' . $error . '")</script>';
} else {

?>
<!DOCTYPE HTML>
<html>
    <head>
        <title>Inventory System</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="resources/css/styles.css"> 
    </head>
    <body>
        <script>
            function myFunction() {
               document.getElementById("demo").style.color = "red";
            }
        </script>
        <br>
        <h2 class="center_text">Delete a Motorcycle from Inventory</h2>
        <br>
        <div>
            <table class="inventory_table center_content center_text">
                <thead>
                    <tr>
                        <th>Brand</th>
                        <th>Model</th>
                        <th>year</th>
                        <th>type</th>
                        <th>VIN</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                    if (mysqli_num_rows($result) > 0){
                        while($info = mysqli_fetch_array($result)){
                            $brand = stripslashes($info['brand']);
                            $model = stripslashes($info['model']);
                            $year = stripslashes($info['year']);
                            $type = stripslashes($info['type']);
                            $vin = stripslashes($info['vin']);

                            echo "<tr>
                                    <td>$brand</td>
                                    <td>$model</td>
                                    <td>$year</td>
                                    <td>$type</td>
                                    <td>$vin</td>
                                    <td>" . '
                                        <form action="deleteItem.php" method="POST" name="removeItem">
                                            <input type="hidden" value="' . $vin . '" name="vin"/>
                                            <input type="submit" value="Delete" name="delete"/>
                                        </form>
                                    </td>
                                  </tr>';
                        }
                    }
                ?>
                </tbody>
            </table>
        </div>
    </body>
</html>
<?php

}
?>