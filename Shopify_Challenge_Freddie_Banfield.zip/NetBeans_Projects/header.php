<?php
    session_start();
    
?>
<!DOCTYPE HTML>
<!--Made by Freddie Banfield, Date: 16/01/2022-->
<html>
    <head>
        <title>Inventory System</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="resources/css/styles.css"> 
    </head>
    <body>
        <header>
            <div>
                <h1 class="center_text">Inventory System</h1>
            </div>
            <div>
                <ul class="center_text" id="header_menu">
                    <li><a href="createItem.php">Create Inventory Item</a></li>
                    <li><a href="editItem.php">Edit Inventory Item</a></li>
                    <li><a href="deleteItem.php">Delete Inventory Item</a></li>
                    <li><a href="viewList.php">View Inventory</a></li>
                </ul>
            </div>
            <div id="profile_container"> 
                <img src="resources/images/default_avatar.png" alt="default avatar picture" id="profile_picture"/>
                <p class="center_text"><?php echo $_SESSION['username'];?></p>
                <p class="center_text"><a href="logout.php">logout</a></p>
            </div>
        </header>
    </body>
</html>