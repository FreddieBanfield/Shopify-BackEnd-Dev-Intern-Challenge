<?php

require 'header.php';
require 'connectToDatabase.php';

if (filter_input(INPUT_POST, 'vin')){
    
    $brand = filter_input(INPUT_POST, 'brand');
    $model = filter_input(INPUT_POST, 'model');
    $year = filter_input(INPUT_POST, 'year');
    $type = filter_input(INPUT_POST, 'type');
    $vin = filter_input(INPUT_POST, 'vin');
    $old_vin = filter_input(INPUT_POST, 'oldvin');
    
    $username = $_SESSION['username'];

    //Delete from table inventory first, due to constraints
    $query = 'DELETE FROM Inventory WHERE vin = "' . $old_vin . '";';
    $result = mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);
    
    //Delete from motorcycles second
    $query = 'DELETE FROM Motorcycle WHERE vin = "' . $old_vin . '";';
    $result = mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);
    
    
    //recreate motorcycle in the motorcycle table
    $query = "INSERT INTO Motorcycle (brand, model, year, type, vin) VALUES('" .$brand . "', '" . $model . "', '" . $year ."', '" . $type ."', '" . $vin ."');";
    mysqli_query($mysqli, $query) or $error = mysqli_error($mysqli);

    //recreate item in inventory table
    $query = "INSERT INTO Inventory (username, vin) VALUES('" .$username . "', '" . $vin . "');";
    mysqli_query($mysqli, $query) or $error = $error . " and " . mysqli_error($mysqli);

    $mysqli->close();
    
    if ($error != "") {
        // Display the alert box for a fail
        echo '<script>alert("Bike was unable to be edited \nError: ' . $error . '")</script>';
    } else {
        // Display the alert box for a success
        echo '<script>alert("Bike edited")</script>';
    }
}else{
    header('location: editItem.php');
}
?>
