<?php
//This code connects to database. It will be used across many pages

$servername = "localhost";
$username = "root";
$password = "HtTlBnVc4UER";
$database = "inventory_list";

$mysqli = mysqli_connect($severname, $username, $password, $database);

if (!$mysqli) {
    $error = ("Connection failed " . mysqli_connect_error());
}



?>